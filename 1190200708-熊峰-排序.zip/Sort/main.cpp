#include"Header.h"

int main()
{
	int n;
	cout << "Please input the numbers of the data:"<<endl;
	cin >> n;
	ShowTime(n);
	return 0;
}